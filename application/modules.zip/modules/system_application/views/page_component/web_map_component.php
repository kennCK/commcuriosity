<div class="web_map_component" >
    <link href="<?=asset_url('css/leaflet.css')?>" rel="stylesheet">
    <link href="<?=asset_url('css/leaflet.label.css')?>" rel="stylesheet">
    <link href="<?=asset_url('css/leaflet-custom.css')?>" rel="stylesheet">
    <!--<link href="<?=asset_url('css/leaflet-search.src.css')?>" rel="stylesheet">-->
    <link href="<?=asset_url('css/easy-button.css')?>" rel="stylesheet">
    <link href="<?=asset_url('css/MarkerCluster.css')?>" rel="stylesheet">
    <link href="<?=asset_url('css/MarkerCluster.Default.css')?>" rel="stylesheet">
    <link href="<?=asset_url('css/Control.OSMGeocoder.css')?>" rel="stylesheet">
    

    <div class="mapHolder" data-mode="" style="position: absolute;float: left;z-index: 1;height:100%;width:100%">
        <input type="hidden" data-map-markers="" value="" name="map-geojson-data" />
    </div>
</div>