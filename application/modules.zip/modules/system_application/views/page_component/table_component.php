<div class="table_component ml-container-botton full-height">
    <div class="col-md-2 ml-list-controls">
        <form action="" class="tableComponentFilterForm form-inline" method="post">
            
            <div class="form-group">
                <button type="submit" class="btn btn-raised btn-warning btn-sm"><span class="glyphicon glyphicon-filter" aria-hidden="true"></span> Filter</button>
            </div>
        </form>
    </div>
    
    
    <div class="col-md-10 ml-list">
        <table class="tableComponentTable table table-hover">
            <thead>
                <tr>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
    </div>
    <div class="prototype" style="display:none">
        <input name="sort" value="0" type="hidden">
        <table>
            <th class="tableComponentColumnHead" ><span class="tableComponentColumnName"></span> <span class="tableComponentColumnSortIndicator glyphicon glyphicon-triangle-bottom" ></span></th>
        </table>
        <div class="tableComponentFilterOptionSelect form-group">
            <label></label>
            <select class="form-control">
            </select>
        </div>
        <div class="tableComponentFilterOption form-group">
            <label></label>
            <input class="form-control">
        </div>
        <ul class="list-group">
                <li class="list-group-item">
                    <span class="badge">14</span> Registered
                </li>
                <li class="list-group-item">
                    <span class="badge">2</span> Paid
                </li>
                <li class="list-group-item">
                    <span class="badge">1</span> Pending
                </li>
            </ul>
            <hr>
            <div class="form-group">
                <label>Group by</label>
                <select class="form-control">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                </select>
            </div>
    </div>
</div>
