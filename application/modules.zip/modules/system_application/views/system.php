<div id="systemComponent">
    <div id="pageComponentContainer" style="display:none">
    </div>
    <div class="moduleHolder full-height">
        
    </div>
</div>
    